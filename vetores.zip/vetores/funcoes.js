function exe1() {
    let vet = []
    let par = []
    let impar = []
    for (let i = 0; i < 6; i++) {
        vet[i] = Number(prompt(`Insira o ${i + 1}° número: `))
    }
    for (let i = 0; i < 6; i++) {
        if (vet[i]%2 == 0) {
            par.push(vet[i])
        }
        else {
            impar.push(vet[i])
        }
    }
    console.log(`Todos os números pares: ${par}`)
    console.log(`Quantidade de números pares: ${par.lenght}`)
    console.log(`Todos os números ímpares: ${impar}`)
    console.log(`Quantidade de números ímpares: ${impar.lenght}`)
}

function exe2() {
    let vet = []
    let mult2 = []
    let mult3 = []
    let mult2e3 = []
    for (let i = 0; i < 7; i++) {
        vet[i] = Number(prompt(`Insira o ${i + 1}° número: `))
    }
    for (let i = 0; i < 7; i++) {
        if (vet[i]%2 == 0 && vet[i]%3 == 0) {
            mult2e3.push(vet[i])
        }
        if (vet[i]%2 == 0) {
            mult2.push(vet[i])
        }
        if (vet[i]%3 == 0) {
            mult3.push(vet[i])
        }
    }
    console.log(`Múltiplos de 2: ${mult2}`)
    console.log(`Múltiplos de 3: ${mult3}`)
    console.log(`Múltiplos de 2 e 3: ${mult2e3}`)
}